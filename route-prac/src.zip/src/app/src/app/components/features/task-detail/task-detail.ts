import { Component, Input, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-detail',
  imports: [],
  templateUrl: './task-detail.html',
  styleUrl: './task-detail.scss',
})
export class TaskDetail implements OnDestroy, OnInit {
  @Input('id') taskId!: string;
  isLoading = true;
  startTime!: number;

  ngOnInit(): void {
    this.startTime = Date.now();
    setTimeout(() => {
      this.isLoading = false;
    }, 1000);
  }

  ngOnDestroy(): void {

    const durationSeconds = (Date.now() - this.startTime) / 1000;
    console.log(`Session for Task ${this.taskId} ended. You spent ${durationSeconds.toFixed(2)} seconds`);
  }
}
